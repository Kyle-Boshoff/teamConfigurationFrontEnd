package com.teamConfiguration.teamConfiguration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamConfigurationApplicationTests {

	@Test
	void contextLoads() {
	}

}
