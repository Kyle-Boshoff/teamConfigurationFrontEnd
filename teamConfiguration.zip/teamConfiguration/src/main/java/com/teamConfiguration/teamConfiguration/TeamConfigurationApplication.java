package com.teamConfiguration.teamConfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamConfigurationApplication.class, args);
	}

}

